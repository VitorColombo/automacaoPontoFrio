package com.vemser.correcao.data.factory;

import com.vemser.correcao.data.dto.PlaceHolderDto;
import com.vemser.correcao.util.DataFakerGenerator;

public class PlaceHolderData {
    DataFakerGenerator faker = new DataFakerGenerator();

    public PlaceHolderDto defaultData() {
        PlaceHolderDto placeHolderDto = new PlaceHolderDto();
        placeHolderDto.setAtributo1("atributo1");

        return placeHolderDto;
    }

    public PlaceHolderDto desenvolvimentoDeSistemas() {
        PlaceHolderDto placeHolderDto = new PlaceHolderDto();
        placeHolderDto.setAtributo1("Desenvolvimento de Sistemas");

        return placeHolderDto;
    }

}