package com.vemser.correcao.page;

import org.openqa.selenium.By;

public class HomePage extends BasePage{
    private static final By inputBusca =
            By.cssSelector("#search-field");
    private static final By ultimosEditaisColumn =
            By.cssSelector("#editais_widget-2 > div.ultimos-editais > h2");

    public String validarHomePage() {
        return lerTexto(ultimosEditaisColumn);
    }
    public void clicarComponenteBusca() {
        clicar(inputBusca);
    }
    public void preencherComponenteBusca(String place) {
        preencherInput(inputBusca, place);
    }
    public void enviarBusca() {
        elemento(inputBusca).submit();
    }
}
