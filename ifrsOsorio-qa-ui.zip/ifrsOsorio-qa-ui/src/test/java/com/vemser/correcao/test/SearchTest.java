package com.vemser.correcao.test;

import com.vemser.correcao.data.dto.PlaceHolderDto;
import com.vemser.correcao.data.factory.PlaceHolderData;
import com.vemser.correcao.page.HomePage;
import com.vemser.correcao.page.SearchPage;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class SearchTest extends BaseTest{
    HomePage homePage = new HomePage();
    SearchPage searchPage = new SearchPage();

    @Test
    public void testComponenteBusca() {
        PlaceHolderData placeHolderData = new PlaceHolderData();
        PlaceHolderDto placeHolderDto = placeHolderData.desenvolvimentoDeSistemas();
        String ultimosEditais = homePage.validarHomePage();
        assertEquals("Últimos Editais", ultimosEditais);
        homePage.preencherComponenteBusca(placeHolderDto.getAtributo1());
        homePage.enviarBusca();

        assertTrue(searchPage.lerResultadoBusca().contains(placeHolderDto.getAtributo1()));
    }
}
